
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `passcode` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `admin`
--

INSERT INTO `admin` (`id`, `username`, `passcode`) VALUES
(0, 'admin', 'admin3'),
(1, 'g.szkop', 'Wielton2'),
(2, 'a.straccini', 'straccini'),
(3, 'k.murri', 'murri'),
(4, 'd.stanek', 'stanek'),
(5, 'a.malvestuto', 'malvestuto'),
(6, 'k.tokarek', 'tokarek'),
(7, 'a.mowczan', 'mowczan'),
(8, 'm.kuzbinski', 'kuzbinski'),
(9, 'a.ogorek', 'ogorek'),
(10, 'p.tadel', 'tadel'),
(11, 'a.forcucci', 'forcucci'),
(12, 'm.pomante', 'pomante'),
(13, 'p.nowak', 'nowak1'),
(14, 'r.spychala', 'spychala2'),
(15, 'a.garbiec', 'garbiec7'),
(16, 'r.silvestri', 'silvestri1');
