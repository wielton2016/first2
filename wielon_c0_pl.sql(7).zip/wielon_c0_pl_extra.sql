
--
-- Indeksy dla zrzutów tabel
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `indeksy`
--
ALTER TABLE `indeksy`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `nadwozie`
--
ALTER TABLE `nadwozie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp`
--
ALTER TABLE `temp`
  ADD PRIMARY KEY (`a`);

--
-- Indexes for table `tlumacz`
--
ALTER TABLE `tlumacz`
  ADD UNIQUE KEY `ID` (`id`);

--
-- Indexes for table `zapisane`
--
ALTER TABLE `zapisane`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `indeksy`
--
ALTER TABLE `indeksy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT dla tabeli `nadwozie`
--
ALTER TABLE `nadwozie`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT dla tabeli `temp`
--
ALTER TABLE `temp`
  MODIFY `a` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT dla tabeli `tlumacz`
--
ALTER TABLE `tlumacz`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=780;
--
-- AUTO_INCREMENT dla tabeli `zapisane`
--
ALTER TABLE `zapisane`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2955;