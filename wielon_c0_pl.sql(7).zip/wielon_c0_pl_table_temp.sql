
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `temp`
--

CREATE TABLE `temp` (
  `a` int(11) NOT NULL,
  `wys` varchar(20) NOT NULL,
  `b` int(11) NOT NULL,
  `c` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Zrzut danych tabeli `temp`
--

INSERT INTO `temp` (`a`, `wys`, `b`, `c`) VALUES
(1, '2750', 0, 0);
