
-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `nadwozie`
--

CREATE TABLE `nadwozie` (
  `id` int(2) NOT NULL,
  `dropside` varchar(500) DEFAULT NULL,
  `front wall` varchar(18) DEFAULT NULL,
  `upper structure` varchar(59) DEFAULT NULL,
  `roof type` varchar(50) DEFAULT NULL,
  `double plywood on front wall` varchar(3) DEFAULT NULL,
  `height` int(4) DEFAULT NULL,
  `upper structure planks` varchar(55) DEFAULT NULL,
  `drawing` varchar(12) DEFAULT NULL,
  `NR QAD` varchar(7) DEFAULT NULL,
  `NR QAD of front wall` varchar(7) DEFAULT NULL,
  `NR QAD of rear` varchar(7) DEFAULT NULL,
  `NR QAD roof` varchar(7) DEFAULT NULL,
  `NR QAD planks pockets` varchar(50) DEFAULT NULL,
  `Nr QAD Hestal pillar` varchar(7) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `nadwozie`
--

INSERT INTO `nadwozie` (`id`, `dropside`, `front wall`, `upper structure`, `roof type`, `double plywood on front wall`, `height`, `upper structure planks`, `drawing`, `NR QAD`, `NR QAD of front wall`, `NR QAD of rear`, `NR QAD roof`, `NR QAD planks pockets`, `Nr QAD Hestal pillar`) VALUES
(1, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2600, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', '', '', 'K234020', 'K233995', ''),
(2, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2650, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', '', '', 'K234020', 'K233995', ''),
(3, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2700, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', 'K234026', 'K032174', 'K032465', 'K234020', 'K233995', 'K032110'),
(4, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2750, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', 'K234030', 'K031978', 'K032437', 'K234020', 'K233995', 'K032137'),
(5, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2800, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', 'K234312', 'K031981', 'K032462', 'K234020', 'K233995', 'K032138'),
(6, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2850, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', '', 'K032463', 'K234020', 'K233995', 'K032139'),
(7, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2900, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', '', '', 'K234020', 'K233995', 'K032140'),
(8, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2950, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', 'K234905', 'K234901', 'K032464', 'K234020', 'K233995', 'K032141'),
(9, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 3000, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', '', '', 'K234020', 'K233995', 'K032142'),
(10, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', 'YES', 2700, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', 'K032803', 'K032465', 'K234020', 'K233995', 'K032110'),
(11, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', 'YES', 2750, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'Q135-K234030', '', 'K032800', 'K032437', 'K234020', 'K233995', 'K032137'),
(12, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2600, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(13, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2650, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(14, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2700, '3 rows of alu planks 100mm', 'R054-K234250', 'K234249', 'K032174', 'K034399', 'K234020', 'K234264', 'K031759'),
(15, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2750, '3 rows of alu planks 100mm', 'R054-K234250', '', 'K031978', 'K034398', 'K234020', 'K234264', 'K032049'),
(16, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2800, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(17, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2850, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(18, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2900, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(19, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2950, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(20, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 3000, '3 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K234264', ''),
(21, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2600, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', ''),
(22, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2650, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', ''),
(23, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2700, '4 rows of alu planks 100mm', 'R054-K234250', 'K234248', 'K032174', 'K034399', 'K234020', 'K034409', 'K031759'),
(24, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2750, '4 rows of alu planks 100mm', 'R054-K234250', 'K234250', 'K031978', 'K034398', 'K234020', 'K034409', 'K032049'),
(25, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2800, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', ''),
(26, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2850, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', ''),
(27, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2900, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', ''),
(28, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2950, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', ''),
(29, 'K031360- H800-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 3000, '4 rows of alu planks 100mm', 'R054-K234250', '', '', '', 'K234020', 'K034409', 'K032059'),
(30, NULL, 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'multipoint', NULL, 2700, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'R177-K233910', 'K234018', 'K032581', 'K233996', 'K233904', 'K233995', 'K032110'),
(31, NULL, 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'multipoint', NULL, 2750, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'R177-K233910', 'K233910', 'K032260', 'K233985', 'K233904', 'K233995', 'K032137'),
(32, NULL, 'Viberti front wall', 'M2 (front wall from PL, rear by IT)', 'lift to load', NULL, 2700, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'P070-K032180', 'K032232', 'K032174', NULL, 'K034970', '6x K032061, 2x K032111', 'K032205'),
(33, '', 'Viberti front wall', 'M2 (front wall from PL, rear by IT)', 'lift to load', '', 2750, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'P070-K032180', 'K032233', 'K031978', NULL, 'K034970', '6x K032061, 2x K032111', 'K032206'),
(35, 'K031532- H600-L3185-bolted with eyelets', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'lift to load', '', 2750, '3 rows of alu planks 100mm', 'R054-K234250', 'K234435', 'K031978', 'K034398', 'K234020', 'K234264', 'K032049'),
(37, '', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'multipoint', '', 2700, '5 rows of alu planks 100mm (1 on floor + 4 per section)', 'R177-K233910', 'K234457', 'K032581', 'K233996', 'K233904', 'K234459', 'K032110'),
(38, '', 'Viberti front wall', 'M2 (front wall from PL, rear by IT)', 'multipoint 5 positions (non standard)', '', 2800, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'P090-K032590', 'K233851', 'K233797', '', 'K034970', '6x K032061, 2x K032111', 'K032207'),
(40, '', 'Viberti front wall', 'M2 (front wall from PL, rear by IT)', 'lift to load', '', 2650, '4 rows of alu planks 100mm (1 on floor + 3 per section)', 'P070-K032180', 'K032553', 'K032550', '', 'K034970', '6x K032061, 2x K032111', 'K032204'),
(41, 'K234790- H800-L3185-bolted, slim profile second from the bottom, no eyeletes', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'multipoint', '', 2700, '4 rows of alu planks 100mm', 'R177-K234800', 'K234805', 'K032581', 'K234787', 'K233904', 'K034409', 'K031759'),
(43, 'K033201- H1000-L3185-bolted with eyelets fixed to 2nd plank from bottom', 'Viberti front wall', 'M3 (aluminium rear pillars and doors, all elements from PL)', 'multipoint', '', 2750, '3 rows of alu planks 100mm', 'R177-K234920', 'K234920', 'K234916', 'K234957', 'K233904', 'K234264', 'K033249');
